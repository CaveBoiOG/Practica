// Obtener elementos del DOM
const container = document.getElementById('container');
const colorFondo = document.getElementById("color-fondo");
const subirImagenFondoBtn = document.getElementById('subir-imagen-fondo');
const colorTexto = document.getElementById("color-texto");
const deleteButton = document.getElementById('deleteButton');
const deleteButton2 = document.getElementById('deleteButton2');
const deleteButton3 = document.getElementById('deleteButton3');
const zoomContainer = document.getElementById('zoomContainer');
const zoomPopup = document.getElementById('zoomPopup');

let selectedElement = null;
let isResizing = false;
let isDragging = false;
let currentHandle = null;
let startX, startY, startWidth, startHeight, startTop, startLeft, offsetX, offsetY;



// ---FONDO---
// Cambiar el color de fondo del contenedor
colorFondo.addEventListener("change", (e) => {
    container.style.backgroundColor = e.target.value;
});

// Cambiar el color de fondo del contenedor
colorFondo.addEventListener("change", (e) => {
    container.style.backgroundColor = e.target.value;
});

// Limpiar el fondo
function limpiarFondo() {
    container.style.backgroundColor = 'transparent';
    container.style.backgroundImage = 'none';
}

// Crear un input para subir imágenes
function crearInputArchivo() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.style.display = 'none';
    return input;
}

// Subir imagen de fondo
subirImagenFondoBtn.addEventListener('click', function() {
    const input = crearInputArchivo();
    input.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                container.style.backgroundImage = `url(${e.target.result})`;
                container.style.backgroundSize = 'cover';
                container.style.backgroundPosition = 'center';
                container.style.backgroundColor = 'transparent';
            };
            reader.readAsDataURL(file);
        }
    });
    input.click();
});

// Eliminar imagen de fondo
function eliminarImagenFondo() {
    container.style.backgroundImage = 'none';
    container.style.backgroundColor = 'transparent';
}



// ---BOTONES---
// Agregar un botón al contenedor
function addButton() {
    const buttonTextInput = document.getElementById('buttonTextInput');
    const buttonLinkInput = document.getElementById('buttonLinkInput');
    const buttonText = buttonTextInput.value.trim();
    const buttonLink = buttonLinkInput.value.trim();

    if (!buttonText || !buttonLink) {
        alert('Ambos campos son obligatorios');
        return;
    }

    const newButton = document.createElement('a');
    newButton.className = 'boton';
    newButton.href = buttonLink;
    newButton.target = '_blank';
    newButton.textContent = buttonText;

    container.appendChild(newButton);
    makeElementDraggable(newButton);
    addResizeHandlesToElement(newButton);

    buttonTextInput.value = '';
    buttonLinkInput.value = '';
}

document.getElementById('addButton').addEventListener('click', addButton);



// ---IMAGENES---
// Subir imagen y agregarla al contenedor
function uploadImage() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.style.display = 'none';
    input.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'imagen';
                img.style.pointerEvents = 'none';
                const contenedorImagen = document.createElement('div');
                contenedorImagen.className = 'contenedorImagen';
                contenedorImagen.appendChild(img);
                container.appendChild(contenedorImagen);
                makeElementDraggable(contenedorImagen);
                addResizeHandlesToElement(contenedorImagen);

                contenedorImagen.addEventListener('click', function(e) {
                    deselectElement();
                    selectedElement = contenedorImagen;
                    selectedElement.classList.add('selected');
                    e.stopPropagation();
                });
            }
            reader.readAsDataURL(file);
        }
    });
    document.body.appendChild(input);
    input.click();
    document.body.removeChild(input);
}

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('uploadImageButton').addEventListener('click', function() {
        uploadImage();
    });
});




//---TEXTOS---
document.addEventListener('DOMContentLoaded', () => {
    document.addEventListener('mousedown', (e) => {
        if (!e.target.classList.contains('text-element') && !e.target.classList.contains('resize-handle')) {
            hideResizeHandles();
        }
    });

    document.getElementById('addTextButton').addEventListener('click', addTextButton);
});

// Agregar controlador de eventos para la tecla "Enter" y llamar a la función addTextButton
const inputText = document.getElementById('inputText');
inputText.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
        addTextButton();
    }
});

function addTextButton() {
    const text = document.getElementById('inputText').value;

    if (text) {
        const textEl = createTextElement(text);
        document.getElementById('container').appendChild(textEl);
        reapplyPropertiesAndEvents(textEl);
        makeMovable(textEl);
        addTextResizeHandles(textEl);
        document.getElementById('inputText').value = '';

        // Ajustar el tamaño inicial
        const rect = textEl.querySelector('div').getBoundingClientRect();
        textEl.style.width = `${rect.width}px`;
        textEl.style.height = `${rect.height}px`;

        selectTextElement(textEl, new Event('click'));
    }
}

// Cambiar el color del texto seleccionado
colorTexto.addEventListener("input", (e) => {
    if (selectedElement && selectedElement.classList.contains('text-element')) {
        const textEl = selectedElement.querySelector('div');
        textEl.style.color = e.target.value;
    }
});

// Convertir un color RGB a su representación hexadecimal
function rgbToHex(rgb) {
    // Convertir "rgb(r, g, b)" a [r, g, b]
    const [r, g, b] = rgb.match(/\d+/g);
    
    // Convertir cada componente a hexadecimal
    return "#" + ((1 << 24) + (parseInt(r) << 16) + (parseInt(g) << 8) + parseInt(b)).toString(16).slice(1);
}

function getTextElementColor(element) {
    const computedStyle = window.getComputedStyle(element);
    const color = computedStyle.getPropertyValue('color');
    return color;
}

const fuenteEstilo = document.getElementById('fuenteEstilo');

fuenteEstilo.addEventListener('change', function () {
    if (selectedElement && selectedElement.classList.contains('text-element')) {
        const textEl = selectedElement.querySelector('div');
        const estiloActual = textEl.style.fontWeight + ' ' + textEl.style.fontStyle + ' ' + textEl.style.textDecoration;

        switch (this.value) {
            case 'normal':
                textEl.style.fontWeight = 'normal';
                textEl.style.fontStyle = 'normal';
                textEl.style.textDecoration = 'none';
                break;
            case 'bold':
                textEl.style.fontWeight = estiloActual.includes('bold') ? 'normal' : 'bold';
                break;
            case 'italic':
                textEl.style.fontStyle = estiloActual.includes('italic') ? 'normal' : 'italic';
                break;
            case 'underline':
                textEl.style.textDecoration = estiloActual.includes('underline') ? 'none' : 'underline';
                break;
        }
    }
});

// Agregar Texto al Contenedor
function createTextElement(text) {
    const textWrapper = document.createElement('div');
    textWrapper.className = 'text-element hide-handles';
    textWrapper.scaleX = 1;
    textWrapper.scaleY = 1;

    const textEl = document.createElement('div');
    textEl.innerText = text;
    textEl.style.margin = '0';
    textEl.style.padding = '0';
    textEl.style.whiteSpace = 'nowrap';
    textEl.style.userSelect = 'none';
    textEl.style.fontSize = '5vh'; // Establecer el tamaño de fuente en 5vh
    textWrapper.appendChild(textEl);

    const computedStyle = window.getComputedStyle(textEl);
    textWrapper.style.width = computedStyle.width;
    textWrapper.style.height = computedStyle.height;

    // Obtener las dimensiones del contenedor
    const containerRect = container.getBoundingClientRect();

    // Calcular la posición central del contenedor
    const containerCenterX = containerRect.left + containerRect.width / 2;
    const containerCenterY = containerRect.top + containerRect.height / 2;

    // Ajustar la posición del elemento de texto para centrarlo
    const textWrapperWidth = textWrapper.offsetWidth;
    const textWrapperHeight = textWrapper.offsetHeight;
    textWrapper.style.left = `${containerCenterX - textWrapperWidth / 2}px`;
    textWrapper.style.top = `${containerCenterY - textWrapperHeight / 2}px`;

    return textWrapper;
}

function selectTextElement(element, e) {
    if (selectedElement) {
        selectedElement.classList.add('hidden-handles');
    }
    element.classList.remove('hidden-handles');
    selectedElement = element;

    // Actualizar el valor del input de color de texto
    const textEl = element.querySelector('div');
    const textColor = window.getComputedStyle(textEl).color;
    colorTexto.value = rgbToHex(textColor);

    e.stopPropagation();
}

function reapplyPropertiesAndEvents(element) {
    selectTextElement(element, new Event('click'));
    addTextResizeHandles(element);

    element.addEventListener('click', function (e) {
        selectTextElement(element, e);
    });

    element.addEventListener('dblclick', function (e) {
        editTextContent(element, e);
    });
}

//editar texto
let isEditing = false;
let editingTextElement = null;

function editTextContent(element, e) {
    if (!isEditing) {
        isEditing = true;
        editingTextElement = element;

        const textEl = element.querySelector('div');
        const contentInput = document.createElement('input');
        contentInput.type = 'text';
        contentInput.value = textEl.innerText;

        // Guardar la escala actual
        const currentScale = {
            x: element.scaleX || 1,
            y: element.scaleY || 1
        };

        // Aplicar estilos al input
        const computedStyle = window.getComputedStyle(textEl);
        contentInput.style.fontSize = computedStyle.fontSize;
        contentInput.style.fontFamily = computedStyle.fontFamily;
        contentInput.style.color = computedStyle.color;
        contentInput.style.fontWeight = computedStyle.fontWeight;
        contentInput.style.fontStyle = computedStyle.fontStyle;
        contentInput.style.textDecoration = computedStyle.textDecoration;
        contentInput.style.width = '100%';
        contentInput.style.border = 'none';
        contentInput.style.outline = 'none';
        contentInput.style.backgroundColor = 'transparent';
        contentInput.style.boxSizing = 'border-box';
        
        // Mantener el tamaño del texto durante la edición
        contentInput.style.transform = `scale(${currentScale.x}, ${currentScale.y})`;
        contentInput.style.transformOrigin = 'left top';
        contentInput.style.width = `${100 / currentScale.x}%`;
        contentInput.style.height = `${100 / currentScale.y}%`;

        contentInput.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                saveTextContent(contentInput.value, element, currentScale);
            }
        });

        contentInput.addEventListener('blur', function () {
            saveTextContent(contentInput.value, element, currentScale);
        });

        element.replaceChild(contentInput, textEl);
        contentInput.focus();
    }

    e.stopPropagation();
}

function saveTextContent(newContent, element, currentScale) {
    const textEl = document.createElement('div');
    textEl.innerText = newContent;
    textEl.style.margin = '0';
    textEl.style.padding = '0';
    textEl.style.whiteSpace = 'nowrap';
    textEl.style.userSelect = 'none';
    textEl.style.display = 'inline-block'; // Asegura que el div se ajuste al contenido

    // Copiar los estilos del elemento original
    const computedStyle = window.getComputedStyle(element.firstChild);
    textEl.style.fontFamily = computedStyle.fontFamily;
    textEl.style.fontSize = computedStyle.fontSize;
    textEl.style.fontWeight = computedStyle.fontWeight;
    textEl.style.fontStyle = computedStyle.fontStyle;
    textEl.style.textDecoration = computedStyle.textDecoration;
    textEl.style.color = computedStyle.color;

    // Reemplazar el contenido antiguo con el nuevo
    element.replaceChild(textEl, element.firstChild);

    // Aplicar la escala guardada
    element.scaleX = currentScale.x;
    element.scaleY = currentScale.y;

    // Resetear el tamaño del contenedor
    element.style.width = 'auto';
    element.style.height = 'auto';

    // Aplicar la transformación al texto
    textEl.style.transform = `scale(${currentScale.x}, ${currentScale.y})`;
    textEl.style.transformOrigin = 'top left';

    // Calcular y aplicar el nuevo tamaño del contenedor
    const rect = textEl.getBoundingClientRect();
    element.style.width = `${rect.width}px`;
    element.style.height = `${rect.height}px`;

    // Ajustar el tamaño del texto para que llene el contenedor
    textEl.style.width = `${100 / currentScale.x}%`;
    textEl.style.height = `${100 / currentScale.y}%`;

    textEl.addEventListener('dblclick', function (e) {
        editTextContent(element, e);
    });

    isEditing = false;
    editingTextElement = null;

    // Actualizar las posiciones de los handles
    updateHandlePositions(element);

    // Actualizar la selección y el color del input
    selectTextElement(element, new Event('click'));
}


// Obtener todos los elementos de texto
const textElements = document.querySelectorAll('.texto');

// Agregar un evento de "dobleclick" a cada elemento de texto
textElements.forEach(textElement => {
    textElement.addEventListener('dblclick', function(e) {
        editTextContent(textElement, e);
    });

    const textEl = textElement.querySelector('div');
    textEl.addEventListener('dblclick', function(e) {
        editTextContent(textElement, e);
    });
});



// ---ELIMINAR---
// Deseleccionar el elemento seleccionado
function deselectElement() {
    if (selectedElement) {
        selectedElement.classList.remove('selected');
        selectedElement = null;
    }
}

// Eliminar la imagen seleccionada
deleteButton.addEventListener('click', function() {
    if (selectedElement && selectedElement.classList.contains('contenedorImagen')) {
        selectedElement.remove();
        selectedElement = null;
    }
});

// Eliminar el texto seleccionado
deleteButton2.addEventListener('click', function() {
    if (selectedElement && selectedElement.classList.contains('text-element')) {
        selectedElement.remove();
        selectedElement = null;
    }
});

// Eliminar el botón seleccionado
deleteButton3.addEventListener('click', function() {
    if (selectedElement && selectedElement.classList.contains('boton')) {
        selectedElement.remove();
        selectedElement = null;
    }
});




// ---ARRASTRE, REDIMENCIONAMIENTO Y ESCALA---
// Crear un manejador de redimensionamiento
function createResizeHandle(position) {
    const handle = document.createElement('div');
    handle.classList.add('resize-handle', position);
    handle.addEventListener('mousedown', initResize);
    return handle;
}

// Agregar manejadores de redimensionamiento a un elemento
function addResizeHandlesToElement(element) {
    const handlesContainer = document.createElement('div');
    handlesContainer.className = 'resize-handles-container';

    const positions = ['top-left', 'top-right', 'bottom-left', 'bottom-right', 'top', 'bottom', 'left', 'right'];
    positions.forEach(position => {
        const handle = createResizeHandle(position);
        handlesContainer.appendChild(handle);
    });

    element.appendChild(handlesContainer);
}

// Hacer un elemento arrastrable
function makeElementDraggable(element) {
    element.addEventListener('mousedown', startDrag);
}

// Iniciar el arrastre
function startDrag(e) {
    if (!e.target.classList.contains('resize-handle')) {
        isDragging = true;
        selectedElement = e.target;
        const rect = selectedElement.getBoundingClientRect();
        offsetX = e.clientX + window.scrollX - rect.left;
        offsetY = e.clientY + window.scrollY - rect.top;
        document.addEventListener('mousemove', drag);
        document.addEventListener('mouseup', stopDrag);
        e.preventDefault(); // Evitar selección de texto durante el arrastre
    }
}

// Arrastrar el elemento
function drag(e) {
    if (isDragging && selectedElement) {
        const containerRect = container.getBoundingClientRect();
        const elementRect = selectedElement.getBoundingClientRect();

        let newX = e.clientX + window.scrollX - offsetX;
        let newY = e.clientY + window.scrollY - offsetY;

        // Restringir el arrastre dentro del contenedor
        newX = Math.max(containerRect.left + window.scrollX, Math.min(containerRect.right + window.scrollX - elementRect.width, newX));
        newY = Math.max(containerRect.top + window.scrollY, Math.min(containerRect.bottom + window.scrollY - elementRect.height, newY));

        selectedElement.style.left = newX + 'px';
        selectedElement.style.top = newY + 'px';

        e.preventDefault(); // Evitar que el documento haga scroll durante el arrastre
        requestAnimationFrame(syncZoomContainer); // Usar requestAnimationFrame para mejor rendimiento
    }
}

// Detener el arrastre
function stopDrag() {
    isDragging = false;
    selectedElement = null;
    document.removeEventListener('mousemove', drag);
    document.removeEventListener('mouseup', stopDrag);
}

function initResize(e) {
    isResizing = true;
    currentHandle = e.target;
    startX = e.clientX + window.scrollX;
    startY = e.clientY + window.scrollY;
    const element = currentHandle.parentElement.parentElement;
    startWidth = parseFloat(getComputedStyle(element).width.replace("px", ""));
    startHeight = parseFloat(getComputedStyle(element).height.replace("px", ""));
    startTop = parseFloat(getComputedStyle(element).top.replace("px", ""));
    startLeft = parseFloat(getComputedStyle(element).left.replace("px", ""));
    document.addEventListener('mousemove', resize);
    document.addEventListener('mouseup', stopResize);
    e.preventDefault();
}

function resize(e) {
    if (isResizing) {
        const element = currentHandle.parentElement.parentElement;
        const dx = e.clientX + window.scrollX - startX;
        const dy = e.clientY + window.scrollY - startY;

        let width = startWidth, height = startHeight, top = startTop, left = startLeft;

        const minSize = 10;

        switch (currentHandle.classList[1]) {
            case 'top-left':
                width = Math.max(minSize, startWidth - dx);
                height = Math.max(minSize, startHeight - dy);
                left = startLeft + (startWidth - width);
                top = startTop + (startHeight - height);
                break;
            case 'top-right':
                width = Math.max(minSize, startWidth + dx);
                height = Math.max(minSize, startHeight - dy);
                top = startTop + (startHeight - height);
                break;
            case 'bottom-left':
                width = Math.max(minSize, startWidth - dx);
                height = Math.max(minSize, startHeight + dy);
                left = startLeft + (startWidth - width);
                break;
            case 'bottom-right':
                width = Math.max(minSize, startWidth + dx);
                height = Math.max(minSize, startHeight + dy);
                break;
            case 'top':
                height = Math.max(minSize, startHeight - dy);
                top = startTop + (startHeight - height);
                break;
            case 'bottom':
                height = Math.max(minSize, startHeight + dy);
                break;
            case 'left':
                width = Math.max(minSize, startWidth - dx);
                left = startLeft + (startWidth - width);
                break;
            case 'right':
                width = Math.max(minSize, startWidth + dx);
                break;
            default:
                return;
        }

        const containerRect = container.getBoundingClientRect();

        // Restricciones de borde
        if (left < containerRect.left + window.scrollX) {
            width = width - (containerRect.left + window.scrollX - left);
            left = containerRect.left + window.scrollX;
        }
        if (top < containerRect.top + window.scrollY) {
            height = height - (containerRect.top + window.scrollY - top);
            top = containerRect.top + window.scrollY;
        }
        if (left + width > containerRect.right + window.scrollX) {
            width = containerRect.right + window.scrollX - left;
        }
        if (top + height > containerRect.bottom + window.scrollY) {
            height = containerRect.bottom + window.scrollY - top;
        }

        // Aplicar los cambios
        element.style.width = width + "px";
        element.style.height = height + "px";
        element.style.top = top + "px";
        element.style.left = left + "px";

        const img = element.querySelector('img');
        if (img) {
            img.style.width = '100%';
            img.style.height = '100%';
        }

        e.preventDefault();
    }
}

function stopResize() {
    isResizing = false;
    document.removeEventListener('mousemove', resize);
    document.removeEventListener('mouseup', stopResize);
}

// Manejo especial para el texto

// Agregar manejadores de redimensionamiento de texto a un elemento
function addTextResizeHandles(element) {
    if (element.classList.contains('text-element') && !element.querySelector('.resize-handle')) {
        const resizeHandles = ['nw', 'ne', 'se', 'sw', 'n', 'e', 's', 'w'];
        resizeHandles.forEach(direction => {
            const handle = document.createElement('div');
            handle.className = `resize-handle resize-handle-${direction}`;
            element.appendChild(handle);

            handle.addEventListener('mousedown', function (event) {
                event.preventDefault();
                event.stopPropagation();
                iniEscala(event, direction, element);
            });
        });

        // Posicionar los handles
        updateHandlePositions(element);

        // Agregar controladores de eventos para mostrar/ocultar los handles
        element.addEventListener('mouseover', function () {
            element.classList.remove('hide-handles');
        });
        element.addEventListener('mouseout', function () {
            element.classList.add('hide-handles');
        });
    }
}

function updateHandlePositions(element) {
    const handles = element.querySelectorAll('.resize-handle');
    const rect = element.getBoundingClientRect();

    handles.forEach(handle => {
        if (handle.classList.contains('resize-handle-nw')) {
            handle.style.top = '-5px';
            handle.style.left = '-5px';
        } else if (handle.classList.contains('resize-handle-ne')) {
            handle.style.top = '-5px';
            handle.style.right = '-5px';
        } else if (handle.classList.contains('resize-handle-se')) {
            handle.style.bottom = '-5px';
            handle.style.right = '-5px';
        } else if (handle.classList.contains('resize-handle-sw')) {
            handle.style.bottom = '-5px';
            handle.style.left = '-5px';
        } else if (handle.classList.contains('resize-handle-n')) {
            handle.style.top = '-5px';
            handle.style.left = '50%';
            handle.style.transform = 'translateX(-50%)';
        } else if (handle.classList.contains('resize-handle-s')) {
            handle.style.bottom = '-5px';
            handle.style.left = '50%';
            handle.style.transform = 'translateX(-50%)';
        } else if (handle.classList.contains('resize-handle-w')) {
            handle.style.left = '-5px';
            handle.style.top = '50%';
            handle.style.transform = 'translateY(-50%)';
        } else if (handle.classList.contains('resize-handle-e')) {
            handle.style.right = '-5px';
            handle.style.top = '50%';
            handle.style.transform = 'translateY(-50%)';
        }
    });
}

// Iniciar el redimensionamiento del texto
function iniEscala(e, direction, element) {
    isResizing = true;
    currentHandle = e.target;
    startWidth = parseInt(getComputedStyle(element).width, 10);
    startHeight = parseInt(getComputedStyle(element).height, 10);
    startTop = parseInt(getComputedStyle(element).top, 10);
    startLeft = parseInt(getComputedStyle(element).left, 10);
    startX = e.clientX + window.scrollX;
    startY = e.clientY + window.scrollY;

    document.documentElement.addEventListener('mousemove', escalaTexto);
    document.documentElement.addEventListener('mouseup', pararEscala);
    e.stopPropagation();
}

// Redimensionar el texto
function escalaTexto(e) {
    if (!isResizing) return;
    const element = currentHandle.parentElement;
    const elementStyle = element.style;
    const containerRect = container.getBoundingClientRect();
    const dx = e.clientX + window.scrollX - startX;
    const dy = e.clientY + window.scrollY - startY;

    let newWidth = startWidth, newHeight = startHeight;
    let newTop = startTop, newLeft = startLeft;

    const minSize = 18; // Tamaño mínimo para el texto

    if (currentHandle.classList.contains('resize-handle-sw')) {
        newWidth = Math.max(minSize, startWidth - dx);
        newHeight = Math.max(minSize, startHeight + dy);
        newLeft = startLeft + (startWidth - newWidth);
    } else if (currentHandle.classList.contains('resize-handle-ne')) {
        newWidth = Math.max(minSize, startWidth + dx);
        newHeight = Math.max(minSize, startHeight - dy);
        newTop = startTop + (startHeight - newHeight);
    } else if (currentHandle.classList.contains('resize-handle-nw')) {
        newWidth = Math.max(minSize, startWidth - dx);
        newHeight = Math.max(minSize, startHeight - dy);
        newTop = startTop + (startHeight - newHeight);
        newLeft = startLeft + (startWidth - newWidth);
    } else if (currentHandle.classList.contains('resize-handle-se')) {
        newWidth = Math.max(minSize, startWidth + dx);
        newHeight = Math.max(minSize, startHeight + dy);
    } else if (currentHandle.classList.contains('resize-handle-n')) {
        newHeight = Math.max(minSize, startHeight - dy);
        newTop = startTop + (startHeight - newHeight);
    } else if (currentHandle.classList.contains('resize-handle-s')) {
        newHeight = Math.max(minSize, startHeight + dy);
    } else if (currentHandle.classList.contains('resize-handle-w')) {
        newWidth = Math.max(minSize, startWidth - dx);
        newLeft = startLeft + (startWidth - newWidth);
    } else if (currentHandle.classList.contains('resize-handle-e')) {
        newWidth = Math.max(minSize, startWidth + dx);
    }

    // Restricciones de borde
    if (newLeft < containerRect.left + window.scrollX) {
        newWidth = newWidth - (containerRect.left + window.scrollX - newLeft);
        newLeft = containerRect.left + window.scrollX;
    }
    if (newTop < containerRect.top + window.scrollY) {
        newHeight = newHeight - (containerRect.top + window.scrollY - newTop);
        newTop = containerRect.top + window.scrollY;
    }
    if (newLeft + newWidth > containerRect.right + window.scrollX) {
        newWidth = containerRect.right + window.scrollX - newLeft;
    }
    if (newTop + newHeight > containerRect.bottom + window.scrollY) {
        newHeight = containerRect.bottom + window.scrollY - newTop;
    }

    const textEl = element.querySelector('div');
    const scaleX = newWidth / startWidth;
    const scaleY = newHeight / startHeight;

    // Actualizar las escalas acumulativas
    element.scaleX = (element.scaleX || 1) * scaleX;
    element.scaleY = (element.scaleY || 1) * scaleY;

    // Ajustar el tamaño del contenedor
    elementStyle.width = `${newWidth}px`;
    elementStyle.height = `${newHeight}px`;

    // Escalar el texto
    textEl.style.transform = `scale(${element.scaleX}, ${element.scaleY})`;
    textEl.style.transformOrigin = 'top left';

    // Ajustar el ancho y alto del texto para mantener las proporciones originales
    textEl.style.width = `${100 / element.scaleX}%`;
    textEl.style.height = `${100 / element.scaleY}%`;

    elementStyle.top = `${newTop}px`;
    elementStyle.left = `${newLeft}px`;

    // Actualizar las variables de inicio para el próximo movimiento
    startWidth = newWidth;
    startHeight = newHeight;
    startTop = newTop;
    startLeft = newLeft;
    startX = e.clientX + window.scrollX;
    startY = e.clientY + window.scrollY;

    // Actualizar las posiciones de los handles
    updateHandlePositions(element);
}
// Detener el redimensionamiento del texto
function pararEscala() {
    isResizing = false;
    document.documentElement.removeEventListener('mousemove', escalaTexto);
    document.documentElement.removeEventListener('mouseup', pararEscala);
}

// Ocultar los manejadores de redimensionamiento
function hideResizeHandles() {
    document.querySelectorAll('.text-element').forEach(element => {
        element.classList.add('hidden-handles');
    });
}

// Hacer un elemento movible
function makeMovable(element) {
    element.addEventListener('mousedown', function (e) {
        if (e.target.classList.contains('resize-handle')) return;

        const offsetX = e.clientX + window.scrollX - parseInt(element.style.left, 10);
        const offsetY = e.clientY + window.scrollY - parseInt(element.style.top, 10);

        function onMouseMove(e) {
            const containerRect = container.getBoundingClientRect();
            const elementRect = element.getBoundingClientRect();

            let newLeft = Math.max(containerRect.left + window.scrollX, Math.min(e.clientX + window.scrollX - offsetX, containerRect.right + window.scrollX - elementRect.width));
            let newTop = Math.max(containerRect.top + window.scrollY, Math.min(e.clientY + window.scrollY - offsetY, containerRect.bottom + window.scrollY - elementRect.height));

            element.style.left = `${newLeft}px`;
            element.style.top = `${newTop}px`;
        }

        function onMouseUp() {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });
}

// Inicialización y asignación de funcionalidades
function initializeElements(container) {
    const elements = document.querySelectorAll('.draggable, .resizable, .text-element');

    elements.forEach(element => {
        if (element.classList.contains('draggable')) {
            makeElementDraggable(element);
        }
        if (element.classList.contains('resizable')) {
            addResizeHandlesToElement(element);
        }
        if (element.classList.contains('text-element')) {
            addTextResizeHandles(element);
        }
    });
}

// Asignar el contenedor y ejecutar la inicialización
initializeElements(container);



//---ZOOM---
//Función para vista previa en zoom
function syncZoomContainer() {
    const zoomElements = zoomContainer.querySelectorAll('.contenedorImagen, .texto, .boton');
    const elements = container.querySelectorAll('.contenedorImagen, .texto, .boton');
    const containerRect = container.getBoundingClientRect();

    elements.forEach((element, index) => {
        const zoomElement = zoomElements[index];
        const computedStyle = window.getComputedStyle(element);

        for (const style of computedStyle) {
            zoomElement.style[style] = computedStyle.getPropertyValue(style);
        }

        const elementRect = element.getBoundingClientRect();
        const scaleFactor = 1.2;

        zoomElement.style.left = (elementRect.left - containerRect.left) * scaleFactor + 'px';
        zoomElement.style.top = (elementRect.top - containerRect.top) * scaleFactor + 'px';
    });

    hideHandlesInZoom();

}

document.getElementById("botonZoom").onclick = function () {
    const zoomPopup = document.getElementById('zoomPopup');

    zoomContainer.innerHTML = '';

    const clone = container.cloneNode(true);

    const elements = container.querySelectorAll('*');
    const cloneElements = clone.querySelectorAll('*');
    const containerRect = container.getBoundingClientRect();

    elements.forEach((element, index) => {
        const cloneElement = cloneElements[index];
        const computedStyle = window.getComputedStyle(element);

        for (const style of computedStyle) {
            cloneElement.style[style] = computedStyle.getPropertyValue(style);
        }

        const elementRect = element.getBoundingClientRect();
        const scaleFactor = 1.2;

        cloneElement.style.left = (elementRect.left - containerRect.left) * scaleFactor + 'px';
        cloneElement.style.top = (elementRect.top - containerRect.top) * scaleFactor + 'px';
    });

    zoomContainer.appendChild(clone);

    const originalWidth = container.offsetWidth;
    const originalHeight = container.offsetHeight;

    const scaleFactor = 1.2;
    zoomContainer.style.width = originalWidth * scaleFactor + 'px';
    zoomContainer.style.height = originalHeight * scaleFactor + 'px';

    clone.style.transform = `scale(${scaleFactor})`;
    clone.style.transformOrigin = 'top left';
    clone.style.position = 'absolute';
    clone.style.top = 0;
    clone.style.left = 0;

    zoomContainer.parentElement.style.width = originalWidth * scaleFactor + 'px';
    zoomContainer.parentElement.style.height = originalHeight * scaleFactor + 'px';

    const zoomContent = zoomContainer.parentElement;
    const availableHeight = window.innerHeight * 0.9;
    if (zoomContent.offsetHeight > availableHeight) {
        zoomContent.style.height = availableHeight + 'px';
        zoomContent.style.overflowY = 'auto';
    } else {
        zoomContent.style.height = 'auto';
        zoomContent.style.overflowY = 'visible';
    }

    zoomPopup.style.display = 'block';

    syncZoomContainer();
};

document.querySelector('.close').onclick = function () {
    document.getElementById('zoomPopup').style.display = 'none';
};

window.onclick = function (event) {
    const zoomPopup = document.getElementById('zoomPopup');
    if (event.target == zoomPopup) {
        zoomPopup.style.display = 'none';
    }
};

container.addEventListener('click', function (e) {
    if (e.target === container) {
        deselectElement();
    }
});

// Ocultar los handles en el contenedor de zoom
function hideHandlesInZoom() {
    const handles = zoomContainer.querySelectorAll('.handle');
    handles.forEach(handle => {
        handle.style.display = 'none';
    });
}