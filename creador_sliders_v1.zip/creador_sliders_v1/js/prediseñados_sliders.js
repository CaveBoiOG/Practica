// Obtener elementos del DOM
const container = document.getElementById('container');
const zoomContainer = document.getElementById('zoomContainer');
const zoomPopup = document.getElementById('zoomPopup');

//---ZOOM---
//Función para vista previa en zoom
function syncZoomContainer() {
    const zoomElements = zoomContainer.querySelectorAll('.contenedorImagen, .texto, .boton');
    const elements = container.querySelectorAll('.contenedorImagen, .texto, .boton');
    const containerRect = container.getBoundingClientRect();

    elements.forEach((element, index) => {
        const zoomElement = zoomElements[index];
        const computedStyle = window.getComputedStyle(element);

        for (const style of computedStyle) {
            zoomElement.style[style] = computedStyle.getPropertyValue(style);
        }

        const elementRect = element.getBoundingClientRect();
        const scaleFactor = 1.2;

        zoomElement.style.left = (elementRect.left - containerRect.left) * scaleFactor + 'px';
        zoomElement.style.top = (elementRect.top - containerRect.top) * scaleFactor + 'px';
    });

    hideHandlesInZoom();

}

document.getElementById("botonZoom").onclick = function () {
    const zoomPopup = document.getElementById('zoomPopup');

    zoomContainer.innerHTML = '';

    const clone = container.cloneNode(true);

    const elements = container.querySelectorAll('*');
    const cloneElements = clone.querySelectorAll('*');
    const containerRect = container.getBoundingClientRect();

    elements.forEach((element, index) => {
        const cloneElement = cloneElements[index];
        const computedStyle = window.getComputedStyle(element);

        for (const style of computedStyle) {
            cloneElement.style[style] = computedStyle.getPropertyValue(style);
        }

        const elementRect = element.getBoundingClientRect();
        const scaleFactor = 1.2;

        cloneElement.style.left = (elementRect.left - containerRect.left) * scaleFactor + 'px';
        cloneElement.style.top = (elementRect.top - containerRect.top) * scaleFactor + 'px';
    });

    zoomContainer.appendChild(clone);

    const originalWidth = container.offsetWidth;
    const originalHeight = container.offsetHeight;

    const scaleFactor = 1.2;
    zoomContainer.style.width = originalWidth * scaleFactor + 'px';
    zoomContainer.style.height = originalHeight * scaleFactor + 'px';

    clone.style.transform = `scale(${scaleFactor})`;
    clone.style.transformOrigin = 'top left';
    clone.style.position = 'absolute';
    clone.style.top = 0;
    clone.style.left = 0;

    zoomContainer.parentElement.style.width = originalWidth * scaleFactor + 'px';
    zoomContainer.parentElement.style.height = originalHeight * scaleFactor + 'px';

    const zoomContent = zoomContainer.parentElement;
    const availableHeight = window.innerHeight * 0.9;
    if (zoomContent.offsetHeight > availableHeight) {
        zoomContent.style.height = availableHeight + 'px';
        zoomContent.style.overflowY = 'auto';
    } else {
        zoomContent.style.height = 'auto';
        zoomContent.style.overflowY = 'visible';
    }

    zoomPopup.style.display = 'block';

    syncZoomContainer();
};

document.querySelector('.close').onclick = function () {
    document.getElementById('zoomPopup').style.display = 'none';
};

window.onclick = function (event) {
    const zoomPopup = document.getElementById('zoomPopup');
    if (event.target == zoomPopup) {
        zoomPopup.style.display = 'none';
    }
};

container.addEventListener('click', function (e) {
    if (e.target === container) {
        deselectElement();
    }
});