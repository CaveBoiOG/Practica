<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Agui Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-----------------------------------------------------------------------------------------------------------
------------------------------------- INICIO ITred Spa slider creador PHP -----------------------------------
------------------------------------------------------------------------------------------------------------- -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Crear Nuevo Slider</title>
  <link rel="stylesheet" href="../css/crear_nuevo_slider.css">
</head>

<body>
  <header>
    <?php
    // Agregar el menú PHP utilizando la función include
    include('../php/menu_creador_sliders.php'); ?>
  </header>
  
  <div><!--Crear nombre de la imagen-->
      <input type="text" id="inputTitulo" placeholder="Ingresar nombre">
      <button id="addTituloButton">Nombrar el Slider</button>
  </div>

  <section class="principal">
      <div class="izquierda">
          <div><!--Agregar imagenes-->
            <p>Subir Imagen desde la PC</p>
            <button id="uploadImageButton">Subir Imagen</button>
            <button id="deleteButton">Eliminar imagen</button>
          </div>

          <div><!--Agregar texto-->
              <p>Agregar Texto</p>
              <input type="text" id="inputText" placeholder="Ingresa texto">
              <button id="addTextButton">Agregar Texto</button>
              <button id="deleteButton2">Eliminar texto</button>
          </div>

          <label for="fuenteEstilo">Estilo de Fuente:</label>
            <select id="fuenteEstilo">
                <option value="normal">Normal</option>
                <option value="bold">Negrita</option>
                <option value="italic">Cursiva</option>
                <option value="underline">Subrayada</option>
            </select>

          <div><!--Cambiar color del texto-->
              <div id="textColorContainer">
                  <p>Cambiar color de texto</p>
                  <input type="color" id="color-texto" />
              </div>
          </div>

          <div><!--Agregar botones-->
              <div id="buttonInputContainer">
                  <p>Agregar botón</p>
                  <input type="text" id="buttonTextInput" placeholder="Texto del botón" />
                  <input type="text" id="buttonLinkInput" placeholder="URL del enlace" />
                  <button id="addButton">Agregar Botón</button>
                  <button id="deleteButton3">Eliminar botón</button>
              </div>
          </div>

          <div>
            <!-- imagen de fondo -->
            <p>Subir imagen de Fondo</p>
            <button id="subir-imagen-fondo">Subir imagen de fondo</button>
            <button onclick="eliminarImagenFondo()">Eliminar fondo</button>
            <!--Cambiar color del fondo-->
            <p>Cambiar color del Fondo</p>
            <input type="color" id="color-fondo" value="#ffffff" />
          </div>


      </div>

      <div class="derecha"><!--Contenedor de Slider-->
          <div class="container" id="container"></div>
          <div class="zboton">
              <button id="botonZoom">Agrandar Vista Previa</button>
          </div>
      </div>
  </section>

  <div id="zoomPopup" class="zoom-popup">
      <div class="zoom-content">
          <span class="close">&times;</span>
          <div id="zoomContainer"></div>
      </div>
  </div>


  <div class="seleccionadores">
      <div class="selectb"> <!--Seleccionadores de paginador bajo-->
          <p>Agregar paginador bajo</p>
          <select id="paginadorBajo">
              <option value="null">Ninguno</option>
              <option value="circuloEntero">Circulo Entero</option>
              <option value="circuloVacio">Circulo Vacio</option>
              <option value="rayaEntera">Raya Entera</option>
              <option value="rayaVacia">Raya Vacia</option>
              <option value="cuadradoEntero">Cuadrado Entero</option>
              <option value="cuadradoVacio">Cuadrado Vacio</option>
          </select>
      </div>

      <div class="selectb"><!--Seleccionadores de paginador lateral-->
          <p>Agregar paginador lateral</p>
          <select id="arrowcontainer">
              <option value="null">Ninguno</option>
              <option value="arrow1"> ⬅ ⮕</option>
              <option value="arrow2">⇐ ⇒</option>
              <option value="arrow3">◄ ►</option>
              <option value="arrow4">◁ ▷</option>
              <option value="arrow5">＜ ＞</option>
          </select>
      </div>

      <div class="selectb"><!--Seleccionadores de animacion para imagenes-->
          <p>Agregar animación de imagen</p>
          <select id="animacionImagen">
              <option value="null">Ninguno</option>
              <option value="difuminar">Difuminar</option>
              <option value="carrusel">Carrusel</option>
              <option value="persiana">Persiana</option>
              <option value="maquinaDeEscribir">Maquina de escribir</option>
          </select>
      </div>

      <div class="selectb"><!--Seleccionadores de animacion para texto-->
          <p>Agregar animación de texto</p>
          <select id="animacionTexto">
              <option value="null">Ninguno</option>
              <option value="difuminar">Difuminar</option>
              <option value="carrusel">Carrusel</option>
              <option value="persiana">Persiana</option>
              <option value="maquinaDeEscribir">Maquina de escribir</option>
          </select>
      </div>
  </div>

  <div class="bajo"><!--botones de Guardar,Eliminar o Crear slider-->
      <button id="crearSliderButton" class="bbajo">Crear nuevo slider</button>
      <button id="guardarSliderButton" class="bbajo">Guardar slider</button>
      <button id="eliminarSliderButton" class="bbajo">Eliminar slider</button>
  </div>


  <!--Script del JS-->
  <script src="../js/crear_nuevo_slider.js"></script>
</body>
</html>

<!-- ------------------------------------------------------------------------------------------------------------
-------------------------------------- FIN ITred Spa slider creador PHP -----------------------------------------
------------------------------------------------------------------------------------------------------------- -->	
     
<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Agui Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->
