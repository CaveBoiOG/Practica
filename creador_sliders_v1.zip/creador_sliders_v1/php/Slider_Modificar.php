<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Agui Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-----------------------------------------------------------------------------------------------------------
------------------------------------- INICIO ITred Spa slider creador PHP -----------------------------------
--------------------------------------------------------------------------------------------------------------->
<?php // Agregar el menú PHP utilizando la función include
include('../php/menu_creador_sliders.php'); ?>

<!DOCTYPE html>
<html lang="es"> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú con PHP</title>
    <link rel="stylesheet" href="../css/Slider_Modificar.css">
</head>
<body>
  <!--Caja de Seleccionar Slider-->
  <div>
  <label for="CajaSlider">Seleccione un Slider:
    <select id="CajaSlider" class="SelectSlider">
    <option selected="" disabled="" value="null">-----------</option>
    </select>
  </label>
  </div>
  
  <!-- Container del Slider -->
  <h1 id="titulo">Vista Previa</h1>
  <div id="centro">
    <div id="container"><!--Container de Sliders-->
      <img id="previewImage" class="draggable resizable">
      <div class="zboton">
        <button id="botonZoom">Agrandar Vista Previa</button>
      </div>
      <div id="elementsContainer"></div>
    </div>
  </div>
  <!-- Ventana de Zoom -->
  <div id="zoomPopup" class="zoom-popup">
    <div class="zoom-content">
      <span class="close">&times;</span>
      <div id="zoomContainer"></div>
    </div>
  </div>

  <!--formulario de Botones-->
  <div class="form" id="botones">
    <form>
    <!--Boton "Guardar Slider"-->
    <input type="button" id="Boton" value="Guardar Slider" />
    <!--Boton "Aplicar Slider"-->
    <input type="button" id="Boton" value="Aplicar Slider" />
    </form>
  </div>
  
  <!--Conexion directa al Js-->
  <script src="../js/Slider_Modificar.js"></script>
</body>
</html>

<!--------------------------------------------------------------------------------------------------------------
-------------------------------------- FIN ITred Spa slider creador PHP ----------------------------------------
------------------------------------------------------------------------------------------------------------- -->
     
<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Agui Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->
