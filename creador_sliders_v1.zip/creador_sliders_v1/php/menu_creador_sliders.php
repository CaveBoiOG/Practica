<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Agui Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-----------------------------------------------------------------------------------------------------------
------------------------------------- INICIO ITred Spa slider creador PHP -----------------------------------
------------------------------------------------------------------------------------------------------------- -->


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Creador Sliders</title>
    <link rel="stylesheet" href="../css/menu_creador_sliders.css">
</head>
    <body><!-- Menu Principal de la pagina Slider -->
        <div class="menu">
        <ul>
            <li><a href="../php/prediseñados_sliders.php">Sliders Prediseñados</a></li>
            <li><a href="../php/crear_nuevo_slider.php">Crear Nuevo Slider</a></li>
            <li><a href="../php/Slider_Modificar.php">Modificar Sliders</a></li>
            <li><a href="../php/slider_eliminar.php">Eliminar Sliders</a></li>
        </ul>
        </div>
    </body>

<!-- ------------------------------------------------------------------------------------------------------------
-------------------------------------- FIN ITred Spa slider creador PHP -----------------------------------------
------------------------------------------------------------------------------------------------------------- -->	
<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Agui Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->