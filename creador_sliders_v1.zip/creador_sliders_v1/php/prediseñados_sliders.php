<?php
    // Agregar el menú PHP utilizando la función include
    include('../php/menu_creador_sliders.php'); ?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar</title>
    <link rel="stylesheet" href="../css/prediseñados_sliders.css">
</head>
<body>

    <div><!--Caja de Seleccion-->
        <label for="CajaSlider">Seleccione un Slider:
        <select id="CajaSlider" class="SelectSlider">
            <!--Informacion-->
            <option selected="" disabled="" value="null">-----------</option>
        </select>
        </label>
    </div>
    
    <!--Container de Sliders y titulo-->
    <h1 id="titulo">Vista Previa</h1>
    <div id="centro">
        <div id="container"><!--Container de Sliders-->
            <img id="previewImage" class="draggable resizable">
            <div class="zboton">
              <button id="botonZoom">Agrandar Vista Previa</button>
            </div>
            <div id="elementsContainer"></div>
        </div>
    </div>
    
    <!-- Ventana de Zoom -->
    <div id="zoomPopup" class="zoom-popup">
      <div class="zoom-content">
          <span class="close">&times;</span>
          <div id="zoomContainer"></div>
      </div>
    </div>
    
    <!--formulario de Botones-->
    <div class="form" id="botones">
        <form>
            <!--Boton "Guardar Slider"-->
            <input type="button" id="Boton" value="Modificar Slider" />
            <!--Boton "Aplicar Slider"-->
            <input type="button" id="Boton" value="Aplicar Slider" />
        </form>
    </div>

  <!--Conexion directa al Js-->
  <script src="../js/prediseñados_sliders.js"></script>
</body>
</html>
